# HM10 Bluetooth Module KiCad Component / Footprint
Simplified Component and Footprint of HM10 Bluetooth Module in KiCad. This is a popular BLE module used by a number of makers.

V1.0 contains the component in it's simplest operational form with four connections (GND, VCC3.3, RX, TX).

Made by [dylankbuckley](https://twitter.com/dylankbuckley)
